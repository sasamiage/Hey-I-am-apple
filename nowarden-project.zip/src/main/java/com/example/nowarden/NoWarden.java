package com.example.nowarden;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.warden.Warden;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;

/**
 * ウォーデンがワールドに出てくるのを止めるMod。
 *  - シュリーカーが呼んだウォーデンも、/summon で呼んだウォーデンも、出現できない
 *  - すでにいるウォーデンも、ワールドを読み込み直すと消える。今すぐ消したいときは /nowarden clear
 *  - ゲームルール(doWardenSpawning)と違って、OP権限（チート）なしでも使える
 */
@Mod(NoWarden.MOD_ID)
public class NoWarden {
    public static final String MOD_ID = "nowarden";

    private static volatile boolean enabled = true;
    private static long lastNoticeTick = -1000;

    public NoWarden(IEventBus modEventBus) {
        load();
        NeoForge.EVENT_BUS.addListener(NoWarden::onEntityJoin);
        NeoForge.EVENT_BUS.addListener(NoWarden::onRegisterCommands);
    }

    // ---------------- ウォーデンの出現を止める ----------------
    private static void onEntityJoin(EntityJoinLevelEvent event) {
        if (!enabled) return;
        if (event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof Warden warden)) return;

        event.setCanceled(true); // ワールドに入れない = 出現しない（読み込み時なら消える）

        if (event.getLevel() instanceof ServerLevel level) {
            long now = level.getGameTime();
            if (now - lastNoticeTick > 100) { // 連続で出さない
                lastNoticeTick = now;
                Component notice = Component.literal("ウォーデンの出現を止めた");
                for (ServerPlayer player : level.players()) {
                    if (player.distanceToSqr(warden) < 64.0 * 64.0) {
                        player.sendSystemMessage(notice, true);
                    }
                }
            }
        }
    }

    // ---------------- コマンド ----------------
    private static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
                Commands.literal("nowarden")
                        // 1人用ならOP権限なしで使える。マルチならOPだけ
                        .requires(src -> src.hasPermission(2) || src.getServer().isSingleplayer())
                        .then(Commands.literal("on").executes(c -> setEnabled(c.getSource(), true)))
                        .then(Commands.literal("off").executes(c -> setEnabled(c.getSource(), false)))
                        .then(Commands.literal("clear").executes(c -> clear(c.getSource())))
                        .executes(c -> status(c.getSource())));
    }

    private static void reply(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal(text), false);
    }

    private static int setEnabled(CommandSourceStack src, boolean value) {
        enabled = value;
        save();
        reply(src, "ウォーデンを出さない: " + (value ? "ON" : "OFF"));
        if (value) {
            reply(src, "今いるウォーデンを消すなら /nowarden clear");
        }
        return 1;
    }

    /** 今読み込まれているウォーデンを全部消す */
    private static int clear(CommandSourceStack src) {
        int count = 0;
        for (ServerLevel level : src.getServer().getAllLevels()) {
            List<Entity> found = new ArrayList<>();
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof Warden) {
                    found.add(entity);
                }
            }
            for (Entity entity : found) {
                entity.discard();
                count++;
            }
        }
        reply(src, "ウォーデンを " + count + " 体消した");
        return 1;
    }

    private static int status(CommandSourceStack src) {
        reply(src, "ウォーデンを出さない: " + (enabled ? "ON" : "OFF"));
        return 1;
    }

    // ---------------- 設定の保存・読み込み ----------------
    private static Path configPath() {
        return FMLPaths.CONFIGDIR.get().resolve("nowarden.txt");
    }

    private static void save() {
        try {
            Files.write(configPath(), List.of("enabled=" + enabled), StandardCharsets.UTF_8);
        } catch (IOException | RuntimeException ignored) {
            // 保存に失敗してもゲームは続ける
        }
    }

    private static void load() {
        try {
            Path path = configPath();
            if (!Files.exists(path)) return;
            for (String line : Files.readAllLines(path, StandardCharsets.UTF_8)) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                if (line.substring(0, eq).trim().equals("enabled")) {
                    enabled = Boolean.parseBoolean(line.substring(eq + 1).trim());
                }
            }
        } catch (IOException | RuntimeException ignored) {
            // 読み込みに失敗したら初期設定のまま
        }
    }
}
